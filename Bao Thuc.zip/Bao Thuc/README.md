# Hướng dẫn thêm chức năng Báo thức (Alarm) cho Xiaozhi ESP32

> 📋 Hướng dẫn chi tiết từng bước để thêm tính năng báo thức vào dự án Xiaozhi ESP32

## 📌 Tổng quan

Hướng dẫn này sẽ giúp bạn thêm chức năng báo thức hoàn chỉnh với các tính năng:
- ✅ Đặt báo thức với giờ/phút cụ thể
- ✅ Báo thức lặp lại hàng ngày
- ✅ Xem danh sách báo thức
- ✅ Xóa báo thức
- ✅ Phát âm thanh khi báo thức kêu (5 lần)

---

## 🗂️ Cấu trúc thư mục

```
xiaozhi-esp32-musicVN/
├── main/
│   ├── alarm_manager.h          # ← Tạo mới
│   ├── alarm_manager.cc         # ← Tạo mới  
│   ├── application.h            # ← Sửa
│   ├── application.cc           # ← Sửa
│   ├── mcp_server.h             # ← Không sửa
│   ├── mcp_server.cc            # ← Sửa
│   ├── CMakeLists.txt           # ← Sửa
│   └── assets/
│       └── common/
│           └── alarm_beep.ogg   # ← Thêm file âm thanh
```

---

## 📝 Bước 1: Copy các file trên git vào đúng cây thư mục như mô tả ở trên.

## 📝 Bước 2: Sửa file `application.h`

**Đường dẫn:** `main/application.h`

### 🔍 Tìm đoạn code này:

```cpp
#include "protocol.h"
#include "ota.h"
#include "audio_service.h"
#include "device_state_event.h"
```

### ✏️ Thêm dòng sau vào cuối các include:

```cpp
#include "protocol.h"
#include "ota.h"
#include "audio_service.h"
#include "device_state_event.h"
#include "alarm_manager.h"  // ← THÊM DÒNG NÀY
```

---

## 📝 Bước 4: Sửa file `application.cc`

**Đường dẫn:** `main/application.cc`

### ✏️ Thay đổi 1: Thêm khởi tạo AlarmManager

**🔍 Tìm đoạn code này trong hàm `Application::Start()`:**

```cpp
void Application::Start() {
    auto& board = Board::GetInstance();
    SetDeviceState(kDeviceStateStarting);

    /* Setup the display */
    auto display = board.GetDisplay();
    display->SetChatMessage("system", SystemInfo::GetUserAgent().c_str());

    /* Setup the audio service */
    auto codec = board.GetAudioCodec();
    audio_service_.Initialize(codec);
    audio_service_.Start();

    AudioServiceCallbacks callbacks;
    // ... tiếp tục
```

**✏️ Thêm đoạn này NGAY SAU `audio_service_.Start();`:**

```cpp
    audio_service_.Start();
    
    // ← THÊM 3 DÒNG NÀY ↓
    /* Initialize Alarm Manager */
    AlarmManager::getInstance().init();
    ESP_LOGI(TAG, "Alarm Manager initialized");
    // ← KẾT THÚC THÊM

    AudioServiceCallbacks callbacks;
```

---

### ✏️ Thay đổi 2: Thêm kiểm tra alarm trong vòng lặp chính

**🔍 Tìm đoạn code này trong hàm `Application::MainEventLoop()`:**

```cpp
        if (bits & MAIN_EVENT_CLOCK_TICK) {
            clock_ticks_++;
            auto display = Board::GetInstance().GetDisplay();
            display->UpdateStatusBar();
        
            // Print the debug info every 10 seconds
            if (clock_ticks_ % 10 == 0) {
```

**✏️ Thêm dòng này NGAY SAU `display->UpdateStatusBar();`:**

```cpp
        if (bits & MAIN_EVENT_CLOCK_TICK) {
            clock_ticks_++;
            auto display = Board::GetInstance().GetDisplay();
            display->UpdateStatusBar();
        
            // ← THÊM DÒNG NÀY ↓
            AlarmManager::getInstance().checkAlarms();  // Kiểm tra alarm mỗi giây
            
            // Print the debug info every 10 seconds
            if (clock_ticks_ % 10 == 0) {
```

---

## 📝 Bước 5: Sửa file `mcp_server.cc`

**Đường dẫn:** `main/mcp_server.cc`

### ✏️ Thay đổi 1: Thêm include

**🔍 Tìm đoạn include ở đầu file:**

```cpp
#include "mcp_server.h"
#include <esp_log.h>
#include <esp_app_desc.h>
#include <algorithm>
#include <cstring>
#include <esp_pthread.h>

#include "application.h"
#include "display.h"
#include "oled_display.h"
#include "board.h"
```

**✏️ Thêm dòng này:**

```cpp
#include "board.h"
#include "settings.h"
#include "lvgl_theme.h"
#include "lvgl_display.h"
#include "boards/common/esp32_music.h"
#include "alarm_manager.h"  // ← THÊM DÒNG NÀY
```

---

### ✏️ Thay đổi 2: Thêm MCP Tools cho Alarm

**🔍 Tìm đoạn code này trong hàm `McpServer::AddCommonTools()`:**

```cpp
#ifdef HAVE_LVGL
    // ... các tool camera, music ...
    
    auto music = board.GetMusic();
    if (music) {
        AddTool("self.music.play_song", ...);
        AddTool("self.music.set_display_mode", ...);
    }
#endif  // ← Đây là dòng đóng #ifdef HAVE_LVGL

    // Restore the original tools list to the end of the tools list
    tools_.insert(tools_.end(), original_tools.begin(), original_tools.end());
}
```

**✏️ Thêm đoạn code Alarm Tools GIỮA `#endif` và `tools_.insert...`:**

```cpp
#endif  // ← Dòng này đã có sẵn (đóng #ifdef HAVE_LVGL)

    // ===== ALARM/REMINDER TOOLS =====
    // ← THÊM TỪ ĐÂY ↓
    AddTool("self.alarm.set",
        "Đặt báo thức hoặc nhắc nhở cho người dùng.\n"
        "Tham số:\n"
        "  `hour`: Giờ (0-23, bắt buộc)\n"
        "  `minute`: Phút (0-59, bắt buộc)\n"
        "  `message`: Nội dung nhắc nhở (tùy chọn)\n"
        "  `repeated`: Lặp lại hàng ngày (true/false, mặc định false)\n"
        "Trả về:\n"
        "  Trạng thái đặt báo thức.",
        PropertyList({
            Property("hour", kPropertyTypeInteger, 0, 23),
            Property("minute", kPropertyTypeInteger, 0, 59),
            Property("message", kPropertyTypeString, "Báo thức"),
            Property("repeated", kPropertyTypeBoolean, false)
        }),
        [](const PropertyList& properties) -> ReturnValue {
            auto& alarm_mgr = AlarmManager::getInstance();
            
            uint8_t hour = static_cast<uint8_t>(properties["hour"].value<int>());
            uint8_t minute = static_cast<uint8_t>(properties["minute"].value<int>());
            bool repeated = properties["repeated"].value<bool>();
            
            AlarmManager::Alarm new_alarm;
            new_alarm.hour = hour;
            new_alarm.minute = minute;
            new_alarm.message = "";
            new_alarm.enabled = true;
            new_alarm.repeated = repeated;
            
            alarm_mgr.addAlarm(new_alarm);

            char buffer[128];
            snprintf(buffer, sizeof(buffer), 
                     "{\"success\": true, \"message\": \"Đã đặt báo thức lúc %02d:%02d\"}",
                     hour, minute);
            
            ESP_LOGI("MCP", "Set alarm: %02d:%02d (repeated: %d)", 
                     hour, minute, repeated);
            
            return std::string(buffer);
        });

    AddTool("self.alarm.list",
        "Xem danh sách tất cả báo thức đã đặt, sắp xếp theo thời gian gần nhất.",
        PropertyList(),
        [](const PropertyList& properties) -> ReturnValue {
            auto& alarm_mgr = AlarmManager::getInstance();
            std::string info = alarm_mgr.getAllAlarmsInfo();
            return "{\"success\": true, \"message\": \"" + info + "\"}";
        });

    AddTool("self.alarm.clear",
        "Xóa tất cả báo thức.",
        PropertyList(),
        [](const PropertyList& properties) -> ReturnValue {
            auto& alarm_mgr = AlarmManager::getInstance();
            alarm_mgr.clearAll();
            return "{\"success\": true, \"message\": \"Đã xóa tất cả báo thức\"}";
        });
    // ← KẾT THÚC THÊM

    // Restore the original tools list to the end of the tools list
    tools_.insert(tools_.end(), original_tools.begin(), original_tools.end());
}  // ← Đóng function, KHÔNG CÓ #endif ở đây
```

---

## 📝 Bước 6: Sửa file `CMakeLists.txt`

**Đường dẫn:** `main/CMakeLists.txt`

### ✏️ Thay đổi 1: Thêm alarm_manager.cc vào danh sách SOURCES

**🔍 Tìm đoạn code này:**

```cmake
set(SOURCES "audio/audio_codec.cc"
            "audio/audio_service.cc"
            # ... nhiều file khác ...
            "device_state_event.cc"
            "assets.cc"
            "main.cc"
            )
```

**✏️ Thêm dòng này TRƯỚC `"main.cc"`:**

```cmake
set(SOURCES "audio/audio_codec.cc"
            "audio/audio_service.cc"
            # ... nhiều file khác ...
            "device_state_event.cc"
            "assets.cc"
            "alarm_manager.cc"  # ← THÊM DÒNG NÀY
            "main.cc"
            )
```

---

### ✏️ Thay đổi 2: Đảm bảo file alarm_beep.ogg được embed

**🔍 Tìm đoạn code này:**

```cmake
file(GLOB LANG_SOUNDS ${CMAKE_CURRENT_SOURCE_DIR}/assets/locales/${LANG_DIR}/*.ogg)
file(GLOB COMMON_SOUNDS ${CMAKE_CURRENT_SOURCE_DIR}/assets/common/*.ogg)

# ... một số dòng khác ...

idf_component_register(SRCS ${SOURCES}
                    EMBED_FILES ${LANG_SOUNDS} ${COMMON_SOUNDS}
                    INCLUDE_DIRS ${INCLUDE_DIRS}
                    WHOLE_ARCHIVE
                    )
```

**✅ Không cần thay đổi gì** - đoạn `${COMMON_SOUNDS}` đã tự động bao gồm tất cả file `.ogg` trong thư mục `assets/common/`, kể cả `alarm_beep.ogg`

---

## 📝 Bước 7: Thêm file âm thanh nếu muốn đổi âm thanh khác

**Đường dẫn:** `main/assets/common/alarm_beep.ogg`

### 📥 Tạo hoặc tải file âm thanh:

1. **Tự tạo:** Dùng Audacity hoặc phần mềm tương tự để tạo âm thanh beep ngắn (khoảng 1-2 giây)
2. **Hoặc tải:** Tìm file âm thanh miễn phí từ các nguồn như:
   - [freesound.org](https://freesound.org)
   - [mixkit.co](https://mixkit.co/free-sound-effects/alarm/)
   - [zapsplat.com](https://www.zapsplat.com/sound-effect-category/alarms/)

3. **Yêu cầu:**
   - Format: `.ogg` (Ogg Vorbis)
   - Độ dài: 1-3 giây
   - Kích thước: < 50KB (để tiết kiệm bộ nhớ)
   - 16000Hz
4. **Chuyển đổi sang OGG:** (nếu file gốc là MP3/WAV)
   ```bash
   ffmpeg -i alarm_beep.mp3 -acodec libvorbis alarm_beep.ogg
   ```

5. **Đặt file vào:** `main/assets/common/alarm_beep.ogg`

---

## 🔨 Build và Flash

### 1. Clean project (khuyến nghị):
```bash
idf.py fullclean
```

### 2. Build:
```bash
idf.py build
```

### 3. Flash: COM là cổng của bạn.
```bash
idf.py flash COM3 monitor
```

---

## 🧪 Kiểm tra hoạt động

### 1. Kiểm tra log khởi động:
Khi khởi động, bạn sẽ thấy log:
```
I (xxxx) AlarmManager: Initializing Alarm Manager
I (xxxx) AlarmManager: Alarm Manager initialized with 0 alarms
I (xxxx) Application: Alarm Manager initialized
```

### 2. Thử đặt báo thức:
Nói với thiết bị:
- **"Đặt báo thức 7 giờ 30"**
- **"Báo thức 8 giờ sáng"**
- **"Nhắc tôi lúc 14h15"**

### 3. Xem danh sách:
- **"Xem báo thức"**
- **"Kiểm tra báo thức"**
- **"Có bao nhiêu báo thức?"**

### 4. Xóa tất cả:
- **"Xóa tất cả báo thức"**
- **"Hủy báo thức"**

---

## 📊 Cấu trúc dữ liệu

### Alarm được lưu trong NVS với format:

```
Key: "alarm_0", "alarm_1", ...
Value: "HH:MM|message|enabled|repeated"
Ví dụ: "07:30|Báo thức|1|0"
```

### Giới hạn:
- Tối đa **10 alarm** cùng lúc
- Mỗi alarm tối đa **256 ký tự** (bao gồm metadata)

---

## 🐛 Xử lý lỗi thường gặp

### Lỗi 1: `alarm_manager.h: No such file or directory`
**Nguyên nhân:** File chưa được tạo hoặc đặt sai vị trí  
**Giải pháp:** Đảm bảo file `alarm_manager.h` nằm trong `main/`

### Lỗi 2: `undefined reference to 'AlarmManager::getInstance()'`
**Nguyên nhân:** Chưa thêm `alarm_manager.cc` vào `CMakeLists.txt`  
**Giải pháp:** Kiểm tra lại Bước 6

### Lỗi 3: `_binary_alarm_beep_ogg_start undefined`
**Nguyên nhân:** File `alarm_beep.ogg` không tồn tại hoặc không được embed  
**Giải pháp:** 
- Đảm bảo file tồn tại tại `main/assets/common/alarm_beep.ogg`
- Chạy `idf.py fullclean` và build lại

### Lỗi 4: Alarm không kêu
**Nguyên nhân:** Thời gian hệ thống chưa được đồng bộ  
**Giải pháp:** 
- Kiểm tra kết nối Wi-Fi
- Kiểm tra cấu hình NTP trong `sdkconfig`

---

## 🎯 Tính năng nâng cao (tùy chọn)

### 1. Thay đổi số lần phát beep:
Trong `alarm_manager.cc`, hàm `triggerAlarm()`:
```cpp
// Thay đổi từ 5 lần sang 3 lần:
for (int i = 0; i < 3; i++) {  // ← Đổi số này
```

### 2. Thay đổi delay giữa các lần phát:
```cpp
vTaskDelay(pdMS_TO_TICKS(2000));  // ← Đổi từ 1000ms sang 2000ms
```

### 3. Thêm snooze (báo lại sau 5 phút):
*Chức năng này yêu cầu thêm nút bấm hoặc lệnh thoại để kích hoạt*

---

## 📚 Tài liệu tham khảo

- [ESP-IDF NVS Documentation](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/storage/nvs_flash.html)
- [FreeRTOS Task Delays](https://www.freertos.org/a00127.html)
- [Xiaozhi ESP32 Original Repo](https://github.com/78/xiaozhi-esp32)

---

## 🤝 Đóng góp

Nếu bạn gặp vấn đề hoặc có ý tưởng cải thiện, vui lòng:
1. Mở issue trên GitHub
2. Hoặc tạo Pull Request với mô tả chi tiết

---

**✨ Chúc bạn thành công! ✨**
